# Vibrant Floral

A responsive, boutique-style florist website for Vibrant Floral in Keelkattalai, Chennai.

## Features
- Responsive mobile-first layout with a soft floral design system
- Product showcase using the supplied flower photographs
- Bouquet category filters and subtle 3D tilt interactions
- Floating petal canvas animation and scroll reveal effects
- Custom bouquet enquiry form that composes a WhatsApp message
- Click-to-call, WhatsApp contact and Google Maps directions
- Local SEO metadata and social sharing metadata

## Local preview
Open `index.html` in a browser or run a static server from this directory:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Business details
- Name: Vibrant Floral
- Phone / WhatsApp: +91 78453 93335
- Address: Shop No. 12, 200 Feet Radial Road, Boopathy Nagar, Keelkattalai, Chennai, Tamil Nadu 600117

Bouquet prices and delivery availability are intentionally enquiry-based because the shop did not provide a verified price list or delivery policy.
